"""
NewERP - Orders GUI
"""

from .order_window import OrderWindow

__all__ = ['OrderWindow']
