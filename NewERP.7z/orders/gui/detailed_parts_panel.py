"""
Detailed Parts Panel - Panel z szczegolowa lista detali
========================================================
Panel z edytowalna tabela detali, filtrami i automatycznym
przeliczaniem kosztow jednostkowych.

Funkcje:
- Thumbnails detali
- Checkbox "Kalkulowac z materialem" (globalny i per detal)
- Edycja wszystkich pol
- Obsluga modeli 3D (STEP, IGES)
- Reczne dodawanie detali bez plikow
"""

import customtkinter as ctk
from tkinter import ttk, messagebox, filedialog, Canvas
from typing import List, Dict, Optional, Callable, Any, Tuple
from pathlib import Path
import logging
import threading
from PIL import Image, ImageTk, ImageDraw
import io

logger = logging.getLogger(__name__)


class Theme:
    """Paleta kolorow"""
    BG_DARK = "#0f0f0f"
    BG_CARD = "#1a1a1a"
    BG_CARD_HOVER = "#252525"
    BG_INPUT = "#2d2d2d"

    TEXT_PRIMARY = "#ffffff"
    TEXT_SECONDARY = "#a0a0a0"
    TEXT_MUTED = "#666666"

    ACCENT_PRIMARY = "#8b5cf6"
    ACCENT_SUCCESS = "#22c55e"
    ACCENT_WARNING = "#f59e0b"
    ACCENT_DANGER = "#ef4444"
    ACCENT_INFO = "#06b6d4"


# ============================================================
# Thumbnail Generator
# ============================================================

class ThumbnailGenerator:
    """Generator miniaturek dla detali"""

    def __init__(self, size: Tuple[int, int] = (60, 40)):
        self.size = size
        self.cache: Dict[str, ImageTk.PhotoImage] = {}

    def generate_from_contour(self, contour: List, color: str = "#8b5cf6") -> ImageTk.PhotoImage:
        """Generuj miniaturke z konturu"""
        if not contour or len(contour) < 3:
            return self._generate_placeholder()

        try:
            # Znajdz bounding box
            xs = [p[0] for p in contour]
            ys = [p[1] for p in contour]
            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)

            width = max_x - min_x
            height = max_y - min_y

            if width <= 0 or height <= 0:
                return self._generate_placeholder()

            # Skaluj do rozmiaru miniaturki
            scale_x = (self.size[0] - 4) / width
            scale_y = (self.size[1] - 4) / height
            scale = min(scale_x, scale_y)

            # Stworz obraz
            img = Image.new('RGBA', self.size, (26, 26, 26, 255))
            draw = ImageDraw.Draw(img)

            # Przeksztalc punkty
            offset_x = (self.size[0] - width * scale) / 2
            offset_y = (self.size[1] - height * scale) / 2

            points = []
            for x, y in contour:
                px = offset_x + (x - min_x) * scale
                py = offset_y + (y - min_y) * scale
                points.append((int(px), int(py)))

            # Rysuj polygon
            if len(points) >= 3:
                # Konwersja koloru hex na RGB
                rgb = tuple(int(color.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))
                draw.polygon(points, fill=rgb + (200,), outline=(255, 255, 255, 255))

            return ImageTk.PhotoImage(img)

        except Exception as e:
            logger.warning(f"Error generating thumbnail: {e}")
            return self._generate_placeholder()

    def _generate_placeholder(self) -> ImageTk.PhotoImage:
        """Generuj placeholder"""
        img = Image.new('RGBA', self.size, (42, 42, 42, 255))
        draw = ImageDraw.Draw(img)
        # Prosty prostokat
        draw.rectangle([2, 2, self.size[0]-3, self.size[1]-3],
                       outline=(100, 100, 100, 255), width=1)
        draw.line([2, 2, self.size[0]-3, self.size[1]-3], fill=(100, 100, 100, 255))
        draw.line([self.size[0]-3, 2, 2, self.size[1]-3], fill=(100, 100, 100, 255))
        return ImageTk.PhotoImage(img)


# ============================================================
# 3D Model Loader
# ============================================================

class Model3DLoader:
    """Loader dla modeli 3D (STEP, IGES)"""

    SUPPORTED_EXTENSIONS = ['.step', '.stp', '.iges', '.igs']

    @staticmethod
    def can_load(filepath: str) -> bool:
        """Sprawdz czy plik jest obslugiwany"""
        ext = Path(filepath).suffix.lower()
        return ext in Model3DLoader.SUPPORTED_EXTENSIONS

    @staticmethod
    def load_model_data(filepath: str) -> Optional[Dict]:
        """
        Wczytaj dane z modelu 3D

        Returns:
            Dict z: weight_kg, bends_count, thickness_mm, width, height, thumbnail_bytes
        """
        try:
            # Proba uzycia OCC (OpenCASCADE)
            try:
                from OCC.Core.STEPControl import STEPControl_Reader
                from OCC.Core.IFSelect import IFSelect_RetDone
                from OCC.Core.BRepGProp import brepgprop_VolumeProperties
                from OCC.Core.GProp import GProp_GProps

                reader = STEPControl_Reader()
                status = reader.ReadFile(filepath)

                if status == IFSelect_RetDone:
                    reader.TransferRoots()
                    shape = reader.OneShape()

                    # Oblicz objetosc
                    props = GProp_GProps()
                    brepgprop_VolumeProperties(shape, props)
                    volume_mm3 = props.Mass()  # w mm3

                    # Zaloz gestosc stali 7850 kg/m3
                    density = 7850  # kg/m3
                    volume_m3 = volume_mm3 / 1e9
                    weight_kg = volume_m3 * density

                    # Bounding box
                    from OCC.Core.Bnd import Bnd_Box
                    from OCC.Core.BRepBndLib import brepbndlib_Add
                    bbox = Bnd_Box()
                    brepbndlib_Add(shape, bbox)
                    xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()

                    return {
                        'weight_kg': round(weight_kg, 3),
                        'bends_count': 0,  # Trudne do wykrycia automatycznie
                        'thickness_mm': round(zmax - zmin, 2),
                        'width': round(xmax - xmin, 2),
                        'height': round(ymax - ymin, 2),
                        'contour': [],  # Projekcja 2D wymaga wiecej pracy
                        'source': '3D_model'
                    }

            except ImportError:
                logger.warning("OCC not available, using fallback 3D parser")

            # Fallback - podstawowe parsowanie
            return Model3DLoader._parse_basic(filepath)

        except Exception as e:
            logger.error(f"Error loading 3D model {filepath}: {e}")
            return None

    @staticmethod
    def _parse_basic(filepath: str) -> Optional[Dict]:
        """Podstawowe parsowanie pliku STEP/IGES"""
        try:
            file_size = Path(filepath).stat().st_size

            # Heurystyka - wieksza czesc = wiekszy detal
            estimated_weight = file_size / 50000  # Bardzo przyblizone

            return {
                'weight_kg': round(estimated_weight, 3),
                'bends_count': 0,
                'thickness_mm': 0,
                'width': 0,
                'height': 0,
                'contour': [],
                'source': '3D_model_estimated',
                'note': 'Dane szacunkowe - brak biblioteki OCC'
            }

        except Exception as e:
            logger.error(f"Basic parse error: {e}")
            return None


# ============================================================
# Editable Treeview with Thumbnails
# ============================================================

class EnhancedTreeview(ttk.Treeview):
    """Treeview z miniaturkami i edytowalnymi komorkami"""

    def __init__(self, parent, columns: List[str], editable_columns: List[str] = None,
                 on_edit: Callable = None, **kwargs):
        # Pierwsza kolumna to miniaturka (tree column)
        super().__init__(parent, columns=columns, show="tree headings", **kwargs)

        self.editable_columns = editable_columns or []
        self.on_edit = on_edit
        self.entry_popup = None
        self.thumbnails: Dict[str, ImageTk.PhotoImage] = {}
        self.thumbnail_generator = ThumbnailGenerator()

        # Kolumna na miniaturki
        self.column("#0", width=70, anchor='center')
        self.heading("#0", text="")

        # Bind double-click for editing
        self.bind("<Double-1>", self._on_double_click)
        self.bind("<Escape>", self._close_entry)

    def insert_with_thumbnail(self, parent: str, index: str, iid: str,
                              values: tuple, contour: List = None,
                              color: str = "#8b5cf6", tags: tuple = None):
        """Wstaw wiersz z miniaturka"""
        # Generuj miniaturke
        if contour and len(contour) >= 3:
            thumb = self.thumbnail_generator.generate_from_contour(contour, color)
        else:
            thumb = self.thumbnail_generator._generate_placeholder()

        self.thumbnails[iid] = thumb

        # Wstaw wiersz
        self.insert(parent, index, iid=iid, values=values, image=thumb, tags=tags)

    def _on_double_click(self, event):
        """Obsluz podwojne klikniecie - rozpocznij edycje"""
        region = self.identify_region(event.x, event.y)
        if region != "cell":
            return

        column = self.identify_column(event.x)
        if column == "#0":  # Miniaturka - nie edytowalna
            return

        col_index = int(column.replace('#', '')) - 1
        if col_index < 0 or col_index >= len(self['columns']):
            return

        col_name = self['columns'][col_index]

        if col_name not in self.editable_columns:
            return

        item = self.identify_row(event.y)
        if not item:
            return

        self._create_entry(item, column, col_name)

    def _create_entry(self, item: str, column: str, col_name: str):
        """Stworz pole edycji"""
        self._close_entry()

        x, y, width, height = self.bbox(item, column)
        current_value = self.set(item, col_name)

        self.entry_popup = ctk.CTkEntry(
            self, width=width, height=height,
            fg_color=Theme.BG_INPUT, text_color=Theme.TEXT_PRIMARY,
            border_width=1, border_color=Theme.ACCENT_PRIMARY
        )
        self.entry_popup.place(x=x, y=y)
        self.entry_popup.insert(0, current_value)
        self.entry_popup.select_range(0, 'end')
        self.entry_popup.focus_set()

        self.entry_popup._item = item
        self.entry_popup._column = col_name

        self.entry_popup.bind("<Return>", self._save_entry)
        self.entry_popup.bind("<Tab>", self._save_and_next)
        self.entry_popup.bind("<Escape>", self._close_entry)
        self.entry_popup.bind("<FocusOut>", self._save_entry)

    def _save_entry(self, event=None):
        """Zapisz wartosc z entry"""
        if not self.entry_popup:
            return

        item = self.entry_popup._item
        column = self.entry_popup._column
        new_value = self.entry_popup.get()

        self.set(item, column, new_value)

        if self.on_edit:
            self.on_edit(item, column, new_value)

        self._close_entry()

    def _save_and_next(self, event=None):
        """Zapisz i przejdz do nastepnej komorki"""
        self._save_entry()
        return "break"

    def _close_entry(self, event=None):
        """Zamknij entry bez zapisu"""
        if self.entry_popup:
            self.entry_popup.destroy()
            self.entry_popup = None


# ============================================================
# Main Panel
# ============================================================

class DetailedPartsPanel(ctk.CTkFrame):
    """Panel z szczegolowa lista detali i kosztami jednostkowymi"""

    # Definicja kolumn (bez thumbnail - to jest #0)
    COLUMNS = [
        ("nr", "Nr", 35),
        ("calc_mat", "Mat", 35),  # Checkbox material
        ("name", "Name", 140),
        ("material", "Material", 70),
        ("thickness", "Thick", 50),
        ("quantity", "Qty", 40),
        ("bends", "Bends", 45),
        ("lm_cost", "L+M", 65),
        ("bending_cost", "Bend$", 55),
        ("additional", "Add$", 50),
        ("weight", "Weight", 55),
        ("cutting_len", "Cut len", 65),
        ("total_unit", "Total/pc", 70),
    ]

    EDITABLE = ["name", "material", "thickness", "quantity", "bends",
                "lm_cost", "bending_cost", "additional", "weight", "cutting_len"]

    # Kolory dla detali (cykliczne)
    PART_COLORS = [
        "#8b5cf6", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4",
        "#ec4899", "#84cc16", "#f97316", "#6366f1", "#14b8a6"
    ]

    def __init__(self, parent, on_parts_change: Callable = None,
                 cost_service=None, **kwargs):
        super().__init__(parent, fg_color=Theme.BG_CARD, corner_radius=8, **kwargs)

        self.on_parts_change = on_parts_change
        self.cost_service = cost_service
        self.parts_data: List[Dict] = []
        self.filter_var = ctk.StringVar()
        self.next_nr = 1

        # Globalne ustawienia
        self.calc_with_material_var = ctk.BooleanVar(value=True)

        self._setup_ui()

    def _setup_ui(self):
        """Buduj interfejs"""
        # === HEADER ===
        header = ctk.CTkFrame(self, fg_color="transparent", height=35)
        header.pack(fill="x", padx=10, pady=(8, 3))

        title = ctk.CTkLabel(
            header, text="LISTA POZYCJI ZAMOWIENIA",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=Theme.TEXT_SECONDARY
        )
        title.pack(side="left")

        # Globalny checkbox
        self.chk_global_material = ctk.CTkCheckBox(
            header, text="Kalkuluj z materialem",
            variable=self.calc_with_material_var,
            command=self._on_global_material_change,
            font=ctk.CTkFont(size=10),
            width=20, height=20,
            checkbox_width=16, checkbox_height=16
        )
        self.chk_global_material.pack(side="right", padx=10)

        # === FILTER BAR ===
        filter_frame = ctk.CTkFrame(self, fg_color="transparent", height=30)
        filter_frame.pack(fill="x", padx=10, pady=2)

        ctk.CTkLabel(filter_frame, text="Filter:", text_color=Theme.TEXT_MUTED,
                     font=ctk.CTkFont(size=10)).pack(side="left", padx=(0, 3))

        self.filter_entry = ctk.CTkEntry(
            filter_frame, width=120, height=24, fg_color=Theme.BG_INPUT,
            textvariable=self.filter_var, font=ctk.CTkFont(size=10)
        )
        self.filter_entry.pack(side="left", padx=3)
        self.filter_entry.bind("<KeyRelease>", self._apply_filter)

        self.filter_combo = ctk.CTkComboBox(
            filter_frame, values=["All", "Material", "Thickness", "Name"],
            width=80, height=24, fg_color=Theme.BG_INPUT, font=ctk.CTkFont(size=10)
        )
        self.filter_combo.set("All")
        self.filter_combo.pack(side="left", padx=3)

        # Spacer
        ctk.CTkLabel(filter_frame, text="").pack(side="left", expand=True)

        # === ACTION BUTTONS ===
        btn_add = ctk.CTkButton(
            filter_frame, text="+ Dodaj", width=60, height=24,
            fg_color=Theme.ACCENT_SUCCESS, hover_color="#1a9f4a",
            font=ctk.CTkFont(size=10), command=self._add_part
        )
        btn_add.pack(side="left", padx=2)

        btn_add_3d = ctk.CTkButton(
            filter_frame, text="+ 3D", width=45, height=24,
            fg_color=Theme.ACCENT_INFO, hover_color="#0599b8",
            font=ctk.CTkFont(size=10), command=self._add_3d_model
        )
        btn_add_3d.pack(side="left", padx=2)

        btn_duplicate = ctk.CTkButton(
            filter_frame, text="Dup", width=40, height=24,
            fg_color=Theme.ACCENT_PRIMARY, hover_color="#7c4fe0",
            font=ctk.CTkFont(size=10), command=self._duplicate_part
        )
        btn_duplicate.pack(side="left", padx=2)

        btn_delete = ctk.CTkButton(
            filter_frame, text="Usun", width=45, height=24,
            fg_color=Theme.ACCENT_DANGER, hover_color="#d93636",
            font=ctk.CTkFont(size=10), command=self._delete_part
        )
        btn_delete.pack(side="left", padx=2)

        btn_recalc = ctk.CTkButton(
            filter_frame, text="Przelicz", width=60, height=24,
            fg_color=Theme.ACCENT_WARNING, hover_color="#db8f0a",
            font=ctk.CTkFont(size=10), command=self._recalculate_all
        )
        btn_recalc.pack(side="left", padx=2)

        # === TREEVIEW TABLE ===
        table_frame = ctk.CTkFrame(self, fg_color="transparent")
        table_frame.pack(fill="both", expand=True, padx=10, pady=(3, 5))

        # Style
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "DetailedParts.Treeview",
            background=Theme.BG_DARK,
            foreground=Theme.TEXT_PRIMARY,
            fieldbackground=Theme.BG_DARK,
            rowheight=45,
            font=('Segoe UI', 9)
        )
        style.configure(
            "DetailedParts.Treeview.Heading",
            background=Theme.BG_CARD,
            foreground=Theme.TEXT_PRIMARY,
            font=('Segoe UI', 9, 'bold')
        )
        style.map("DetailedParts.Treeview",
                  background=[("selected", Theme.ACCENT_PRIMARY)],
                  foreground=[("selected", Theme.TEXT_PRIMARY)])

        # Treeview
        columns = [c[0] for c in self.COLUMNS]
        self.tree = EnhancedTreeview(
            table_frame, columns=columns, editable_columns=self.EDITABLE,
            on_edit=self._on_cell_edit, style="DetailedParts.Treeview", height=6
        )

        # Konfiguracja kolumn
        for col_id, col_name, col_width in self.COLUMNS:
            self.tree.heading(col_id, text=col_name, anchor="center")
            self.tree.column(col_id, width=col_width, anchor="center", minwidth=30)

        # Tagi
        self.tree.tag_configure('with_material', background='#1a2a1a')
        self.tree.tag_configure('without_material', background='#2a1a1a')

        # Scrollbars
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        table_frame.grid_columnconfigure(0, weight=1)
        table_frame.grid_rowconfigure(0, weight=1)

        # === SUMMARY BAR ===
        summary_frame = ctk.CTkFrame(self, fg_color=Theme.BG_INPUT, height=25)
        summary_frame.pack(fill="x", padx=10, pady=(0, 8))

        self.lbl_summary = ctk.CTkLabel(
            summary_frame,
            text="Pozycji: 0 | Suma qty: 0 | L+M: 0.00 | Total: 0.00 PLN",
            font=ctk.CTkFont(size=10), text_color=Theme.TEXT_SECONDARY
        )
        self.lbl_summary.pack(pady=4)

    def _on_global_material_change(self):
        """Zmiana globalnego checkboxa material"""
        include_mat = self.calc_with_material_var.get()
        for part in self.parts_data:
            part['calc_with_material'] = include_mat
        self._refresh_table()
        self._recalculate_all()

    def _on_cell_edit(self, item: str, column: str, new_value: str):
        """Obsluz edycje komorki"""
        idx = self._find_part_index(item)
        if idx is None:
            return

        # Walidacja i konwersja
        try:
            if column in ["quantity", "bends"]:
                self.parts_data[idx][column] = int(new_value)
            elif column in ["thickness", "lm_cost", "bending_cost", "additional",
                            "weight", "cutting_len"]:
                self.parts_data[idx][column] = float(new_value.replace(",", "."))
            elif column == "calc_mat":
                # Toggle material calculation
                self.parts_data[idx]['calc_with_material'] = new_value.lower() in ['1', 'true', 'yes', 'tak']
            else:
                self.parts_data[idx][column] = new_value
        except ValueError:
            logger.warning(f"Invalid value for {column}: {new_value}")
            return

        self._recalculate_part(idx)
        self._update_summary()

        if self.on_parts_change:
            self.on_parts_change(self.parts_data)

    def _find_part_index(self, item_id: str) -> Optional[int]:
        """Znajdz indeks czesci po ID wiersza"""
        try:
            for i, part in enumerate(self.parts_data):
                if part.get('_item_id') == item_id:
                    return i
            values = self.tree.item(item_id, 'values')
            nr = int(values[0])
            for i, part in enumerate(self.parts_data):
                if part.get('nr') == nr:
                    return i
        except:
            pass
        return None

    def _recalculate_part(self, idx: int):
        """Przelicz koszty dla detalu"""
        part = self.parts_data[idx]

        # Przelicz L+M cost na podstawie wagi i dlugosci ciecia
        lm_cost = self._calculate_lm_cost(part)
        part['lm_cost'] = lm_cost

        bending_cost = float(part.get('bending_cost', 0) or 0)
        additional = float(part.get('additional', 0) or 0)

        # Jesli nie kalkulujemy z materialem - odejmij koszt materialu z L+M
        if not part.get('calc_with_material', True):
            # Oblicz sam koszt materialu
            material = part.get('material', '').upper()
            weight_kg = float(part.get('weight', 0) or 0)
            mat_price = self.MATERIAL_PRICES.get(material, self.MATERIAL_PRICES['DEFAULT'])
            material_cost = weight_kg * mat_price
            # Odejmij material, zostaw tylko laser
            lm_cost = max(0, lm_cost - material_cost)

        total_unit = lm_cost + bending_cost + additional
        part['total_unit'] = total_unit

        self._update_row(idx)

    def _recalculate_all(self):
        """Przelicz wszystkie detale"""
        for idx in range(len(self.parts_data)):
            self._recalculate_part(idx)
        self._update_summary()

        if self.on_parts_change:
            self.on_parts_change(self.parts_data)

    def _update_row(self, idx: int):
        """Aktualizuj wiersz w tabeli"""
        part = self.parts_data[idx]
        item_id = part.get('_item_id')
        if item_id:
            self.tree.item(item_id, values=self._part_to_values(part))

    def _part_to_values(self, part: Dict) -> tuple:
        """Konwertuj dane detalu na wartosci dla tabeli"""
        calc_mat = "+" if part.get('calc_with_material', True) else "-"
        return (
            part.get('nr', ''),
            calc_mat,
            part.get('name', ''),
            part.get('material', ''),
            f"{part.get('thickness', 0):.1f}",
            part.get('quantity', 1),
            part.get('bends', 0),
            f"{part.get('lm_cost', 0):.2f}",
            f"{part.get('bending_cost', 0):.2f}",
            f"{part.get('additional', 0):.2f}",
            f"{part.get('weight', 0):.2f}",
            f"{part.get('cutting_len', 0):.0f}",
            f"{part.get('total_unit', 0):.2f}",
        )

    def _update_summary(self):
        """Aktualizuj podsumowanie"""
        total_parts = len(self.parts_data)
        total_qty = sum(p.get('quantity', 1) for p in self.parts_data)
        total_lm = sum(p.get('lm_cost', 0) * p.get('quantity', 1) for p in self.parts_data)
        total_all = sum(p.get('total_unit', 0) * p.get('quantity', 1) for p in self.parts_data)

        self.lbl_summary.configure(
            text=f"Pozycji: {total_parts} | Suma qty: {total_qty} | "
                 f"L+M: {total_lm:,.2f} | Total: {total_all:,.2f} PLN"
        )

    def _refresh_table(self):
        """Odswiez cala tabele"""
        self.tree.delete(*self.tree.get_children())

        for idx, part in enumerate(self.parts_data):
            color = self.PART_COLORS[idx % len(self.PART_COLORS)]
            tag = 'with_material' if part.get('calc_with_material', True) else 'without_material'
            item_id = f"part_{part.get('nr', idx)}"
            part['_item_id'] = item_id

            self.tree.insert_with_thumbnail(
                '', 'end', iid=item_id,
                values=self._part_to_values(part),
                contour=part.get('contour', []),
                color=color,
                tags=(tag,)
            )

    def _add_part(self):
        """Dodaj nowy detal (recznie)"""
        new_part = {
            'nr': self.next_nr,
            'name': f'Detal_{self.next_nr}',
            'material': 'S355',
            'thickness': 2.0,
            'quantity': 1,
            'bends': 0,
            'lm_cost': 0.0,
            'bending_cost': 0.0,
            'additional': 0.0,
            'weight': 0.0,
            'cutting_len': 0,
            'total_unit': 0.0,
            'calc_with_material': self.calc_with_material_var.get(),
            'contour': [],
            'filepath': '',
            'source': 'manual'
        }

        self.next_nr += 1
        self.parts_data.append(new_part)
        self._refresh_table()
        self._update_summary()

        if self.on_parts_change:
            self.on_parts_change(self.parts_data)

    def _add_3d_model(self):
        """Dodaj detal z modelu 3D"""
        filetypes = [
            ("3D Models", "*.step *.stp *.iges *.igs"),
            ("STEP Files", "*.step *.stp"),
            ("IGES Files", "*.iges *.igs"),
            ("All Files", "*.*")
        ]

        files = filedialog.askopenfilenames(
            title="Wybierz modele 3D",
            filetypes=filetypes
        )

        if not files:
            return

        added = 0
        for filepath in files:
            model_data = Model3DLoader.load_model_data(filepath)

            if model_data:
                new_part = {
                    'nr': self.next_nr,
                    'name': Path(filepath).stem,
                    'material': 'S355',
                    'thickness': model_data.get('thickness_mm', 0),
                    'quantity': 1,
                    'bends': model_data.get('bends_count', 0),
                    'lm_cost': 0.0,
                    'bending_cost': 0.0,
                    'additional': 0.0,
                    'weight': model_data.get('weight_kg', 0),
                    'cutting_len': 0,
                    'width': model_data.get('width', 0),
                    'height': model_data.get('height', 0),
                    'total_unit': 0.0,
                    'calc_with_material': self.calc_with_material_var.get(),
                    'contour': model_data.get('contour', []),
                    'filepath': filepath,
                    'source': model_data.get('source', '3D_model')
                }

                self.next_nr += 1
                self.parts_data.append(new_part)
                added += 1
            else:
                logger.warning(f"Could not load 3D model: {filepath}")

        if added > 0:
            self._refresh_table()
            self._update_summary()
            messagebox.showinfo("Sukces", f"Dodano {added} detali z modeli 3D")

            if self.on_parts_change:
                self.on_parts_change(self.parts_data)

    def _duplicate_part(self):
        """Duplikuj zaznaczony detal"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Uwaga", "Wybierz detal do duplikacji")
            return

        idx = self._find_part_index(selection[0])
        if idx is None:
            return

        original = self.parts_data[idx]
        new_part = original.copy()
        new_part['nr'] = self.next_nr
        new_part['name'] = f"{original['name']}_kopia"
        new_part['_item_id'] = None

        self.next_nr += 1
        self.parts_data.append(new_part)
        self._refresh_table()
        self._update_summary()

        if self.on_parts_change:
            self.on_parts_change(self.parts_data)

    def _delete_part(self):
        """Usun zaznaczony detal"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Uwaga", "Wybierz detal do usuniecia")
            return

        if not messagebox.askyesno("Potwierdzenie", "Usunac zaznaczony detal?"):
            return

        idx = self._find_part_index(selection[0])
        if idx is not None:
            del self.parts_data[idx]

        self._refresh_table()
        self._update_summary()

        if self.on_parts_change:
            self.on_parts_change(self.parts_data)

    def _apply_filter(self, event=None):
        """Zastosuj filtr"""
        # W przyszlosci - filtrowanie widocznych wierszy
        pass

    # === MATERIAL PRICES, SPEEDS & DENSITIES ===
    MATERIAL_PRICES = {  # PLN/kg
        'S355': 4.5, 'S235': 4.2, 'DC01': 5.0, 'DC04': 5.2,
        '1.4301': 18.0, '1.4404': 22.0, 'INOX': 18.0,
        'AL': 12.0, 'ALU': 12.0, 'ALUMINIUM': 12.0,
        'DEFAULT': 5.0
    }

    CUTTING_SPEEDS = {  # m/min
        'S355': 3.0, 'S235': 3.2, 'DC01': 3.5, 'DC04': 3.5,
        '1.4301': 2.5, '1.4404': 2.3, 'INOX': 2.5,
        'AL': 4.0, 'ALU': 4.0, 'ALUMINIUM': 4.0,
        'DEFAULT': 3.0
    }

    MATERIAL_DENSITIES = {  # kg/m³
        'S355': 7850, 'S235': 7850, 'DC01': 7850, 'DC04': 7850,
        '1.4301': 7900, '1.4404': 7950, 'INOX': 7900,
        'AL': 2700, 'ALU': 2700, 'ALUMINIUM': 2700,
        'DEFAULT': 7850
    }

    def _calculate_weight_from_dims(self, part_data: Dict) -> float:
        """Oblicz wagę z wymiarów bounding box jeśli brak wagi"""
        width_mm = float(part_data.get('width', 0) or 0)
        height_mm = float(part_data.get('height', 0) or 0)
        thickness_mm = float(part_data.get('thickness', 0) or 0)
        material = part_data.get('material', '').upper()

        if width_mm <= 0 or height_mm <= 0 or thickness_mm <= 0:
            return 0.0

        # Przybliżona powierzchnia = 70% bounding box (typowe detale)
        area_m2 = (width_mm * height_mm * 0.7) / 1e6
        volume_m3 = area_m2 * (thickness_mm / 1000.0)
        density = self.MATERIAL_DENSITIES.get(material, self.MATERIAL_DENSITIES['DEFAULT'])

        return volume_m3 * density

    def _calculate_lm_cost(self, part_data: Dict) -> float:
        """Oblicz koszt L+M (Laser + Material) dla detalu"""
        material = part_data.get('material', '').upper()
        weight_kg = float(part_data.get('weight', 0) or 0)
        cutting_len_mm = float(part_data.get('cutting_len', 0) or 0)
        piercing_count = int(part_data.get('piercing_count', 1) or 1)
        thickness = float(part_data.get('thickness', 0) or 0)

        # Jeśli brak wagi, oblicz z wymiarów
        if weight_kg <= 0:
            weight_kg = self._calculate_weight_from_dims(part_data)
            if weight_kg > 0:
                part_data['weight'] = weight_kg  # Zapisz obliczoną wagę

        # Cena materialu
        mat_price = self.MATERIAL_PRICES.get(material, self.MATERIAL_PRICES['DEFAULT'])
        material_cost = weight_kg * mat_price

        # Koszt ciecia
        cut_speed = self.CUTTING_SPEEDS.get(material, self.CUTTING_SPEEDS['DEFAULT'])
        cutting_len_m = cutting_len_mm / 1000.0
        cutting_time_min = cutting_len_m / cut_speed if cut_speed > 0 else 0
        hourly_rate = 80.0  # PLN/h
        cutting_cost = cutting_time_min * (hourly_rate / 60.0)

        # Koszt przebic (piercing)
        is_inox = material.startswith('1.4') or 'INOX' in material
        if is_inox:
            piercing_time_s = (0.5 + 0.1 * thickness) * piercing_count
        else:
            piercing_time_s = (0.5 + 0.3 * thickness) * piercing_count
        piercing_cost = (piercing_time_s / 60.0) * (hourly_rate / 60.0)

        return material_cost + cutting_cost + piercing_cost

    # === PUBLIC API ===

    def set_parts(self, parts: List[Dict]):
        """Ustaw liste detali"""
        self.parts_data = []
        self.next_nr = 1

        for part in parts:
            weight = float(part.get('weight_kg', part.get('weight', 0)) or 0)
            cutting_len = float(part.get('cutting_len', part.get('cutting_length_mm', part.get('cutting_length', 0))) or 0)

            part_data = {
                'nr': self.next_nr,
                'name': part.get('name', ''),
                'material': part.get('material', ''),
                'thickness': float(part.get('thickness_mm', part.get('thickness', 0)) or 0),
                'quantity': int(part.get('quantity', 1) or 1),
                'bends': int(part.get('bends', part.get('bends_count', 0)) or 0),
                'lm_cost': 0.0,  # Obliczony ponizej
                'bending_cost': float(part.get('bending_cost', part.get('bending', 0)) or 0),
                'additional': float(part.get('additional', 0) or 0),
                'weight': weight,
                'cutting_len': cutting_len,
                'piercing_count': int(part.get('piercing_count', 1) or 1),
                'total_unit': 0.0,
                'calc_with_material': self.calc_with_material_var.get(),
                'contour': part.get('contour', []),
                'holes': part.get('holes', []),
                'filepath': part.get('filepath', ''),
                'width': part.get('width', 0),
                'height': part.get('height', 0),
                'source': part.get('source', 'dxf')
            }

            # Oblicz L+M cost jesli nie podano
            existing_lm = float(part.get('lm_cost', part.get('unit_cost', 0)) or 0)
            if existing_lm > 0:
                part_data['lm_cost'] = existing_lm
            else:
                part_data['lm_cost'] = self._calculate_lm_cost(part_data)

            # Oblicz bending cost jesli sa giecia
            if part_data['bends'] > 0 and part_data['bending_cost'] == 0:
                part_data['bending_cost'] = part_data['bends'] * 3.0  # 3 PLN per giecie

            # Oblicz total
            part_data['total_unit'] = (
                part_data['lm_cost'] +
                part_data['bending_cost'] +
                part_data['additional']
            )

            self.next_nr += 1
            self.parts_data.append(part_data)

        self._refresh_table()
        self._update_summary()

    def get_parts(self) -> List[Dict]:
        """Pobierz liste detali"""
        return self.parts_data

    def get_total_cost(self) -> float:
        """Pobierz calkowity koszt"""
        return sum(p.get('total_unit', 0) * p.get('quantity', 1) for p in self.parts_data)


# === TEST ===
if __name__ == "__main__":
    ctk.set_appearance_mode("Dark")

    root = ctk.CTk()
    root.title("Detailed Parts Panel Test")
    root.geometry("1100x450")

    panel = DetailedPartsPanel(root)
    panel.pack(fill="both", expand=True, padx=10, pady=10)

    # Test data
    test_parts = [
        {'name': 'Plyta_A', 'material': 'S355', 'thickness_mm': 3.0, 'quantity': 5,
         'weight_kg': 2.5, 'cutting_length': 1500, 'unit_cost': 45.0,
         'contour': [(0,0), (100,0), (100,50), (0,50)]},
        {'name': 'Plyta_B', 'material': 'DC01', 'thickness_mm': 1.5, 'quantity': 10,
         'weight_kg': 0.8, 'cutting_length': 800, 'unit_cost': 15.0,
         'contour': [(0,0), (80,0), (80,40), (0,40)]},
        {'name': 'Wspornik', 'material': 'S355', 'thickness_mm': 5.0, 'quantity': 2,
         'weight_kg': 4.2, 'cutting_length': 2200, 'unit_cost': 85.0, 'bending': 12.0,
         'bends': 3, 'contour': [(0,0), (60,0), (60,80), (30,100), (0,80)]},
    ]

    panel.set_parts(test_parts)

    root.mainloop()
