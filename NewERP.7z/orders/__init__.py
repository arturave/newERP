"""
NewERP - Orders Module
======================
Moduł zarządzania zamówieniami.
"""

from .gui.order_window import OrderWindow

__all__ = ['OrderWindow']
