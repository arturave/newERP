"""
Nesting Tabs Panel - Zakładkowy panel nestingu z wieloma arkuszami
===================================================================
Każda kombinacja materiał+grubość ma własną zakładkę z:
- Przewijalną listą arkuszy (wiele arkuszy obok siebie)
- Live preview nestingu z zoom
- Interaktywnym wyborem detali (kliknięcie na arkuszu → lista, kliknięcie na liście → arkusz)
- Kolorowaniem nieznestowanych detali (czerwone tło)
- Podglądem wybranego detalu

Funkcjonalności:
- Kliknięcie na detal na nestingu → zaznacz na liście
- Kliknięcie na liście → podświetl na nestingu (wskaż arkusz)
- Nieznestowane detale mają czerwone tło na liście
- Podgląd detalu z możliwością powiększenia
- Edycja ilości przez podwójne kliknięcie
"""

import customtkinter as ctk
from tkinter import Canvas, ttk, messagebox, filedialog
import threading
import logging
from typing import List, Dict, Optional, Callable, Tuple, Any, Set
from dataclasses import dataclass, field
import os

logger = logging.getLogger(__name__)

# Kolory dla detali (cykliczne)
PART_COLORS = [
    "#8b5cf6", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4",
    "#ec4899", "#84cc16", "#f97316", "#6366f1", "#14b8a6",
    "#a855f7", "#f43f5e", "#0ea5e9", "#eab308", "#64748b"
]


class Theme:
    """Paleta kolorów"""
    BG_DARK = "#0f0f0f"
    BG_CARD = "#1a1a1a"
    BG_CARD_HOVER = "#252525"
    BG_INPUT = "#2d2d2d"
    
    TEXT_PRIMARY = "#ffffff"
    TEXT_SECONDARY = "#a0a0a0"
    TEXT_MUTED = "#666666"
    
    ACCENT_PRIMARY = "#8b5cf6"
    ACCENT_SUCCESS = "#22c55e"
    ACCENT_WARNING = "#f59e0b"
    ACCENT_DANGER = "#ef4444"
    ACCENT_INFO = "#06b6d4"
    
    # Kolory dla statusów detali
    UNPLACED_BG = "#4a1c1c"  # Ciemne czerwone tło dla nieznestowanych
    PLACED_BG = "#1c3a1c"    # Ciemne zielone tło dla znestowanych


# ============================================================
# Part Preview Canvas
# ============================================================

class PartPreviewCanvas(Canvas):
    """Canvas do podglądu pojedynczego detalu - kliknij aby powiększyć"""
    
    def __init__(self, parent, width=200, height=150, **kwargs):
        super().__init__(parent, width=width, height=height, 
                        bg="#1a1a1a", highlightthickness=1, 
                        highlightbackground="#333333", **kwargs)
        self.part_data: Optional[dict] = None
        self.part_color: str = "#3B82F6"
        
        self.bind("<Button-1>", self._on_click)
        self.bind("<Enter>", lambda e: self.configure(cursor="hand2"))
        self.bind("<Leave>", lambda e: self.configure(cursor=""))
    
    def _on_click(self, event):
        """Otwórz duże okno podglądu"""
        if self.part_data and self.part_data.get('contour'):
            self._open_large_preview()
    
    def _open_large_preview(self):
        """Otwórz duże okno z podglądem detalu"""
        root = self.winfo_toplevel()
        
        preview_window = ctk.CTkToplevel(root)
        preview_window.title(f"Podgląd: {self.part_data.get('name', 'Detal')}")
        preview_window.configure(fg_color="#1a1a1a")
        
        win_size = 800
        preview_window.geometry(f"{win_size}x{win_size}")
        preview_window.minsize(600, 600)
        
        preview_window.update_idletasks()
        x = (preview_window.winfo_screenwidth() - win_size) // 2
        y = (preview_window.winfo_screenheight() - win_size) // 2
        preview_window.geometry(f"+{x}+{y}")
        
        large_canvas = Canvas(preview_window, bg="#1a1a1a", highlightthickness=0)
        large_canvas.pack(fill="both", expand=True, padx=20, pady=20)
        
        def on_resize(event):
            self._draw_large_preview(large_canvas)
        
        large_canvas.bind("<Configure>", on_resize)
        preview_window.after(50, lambda: self._draw_large_preview(large_canvas))
        
        btn_close = ctk.CTkButton(preview_window, text="Zamknij", 
                                   command=preview_window.destroy, width=120)
        btn_close.pack(pady=10)
        
        preview_window.focus_set()
        preview_window.grab_set()
    
    def _draw_large_preview(self, canvas: Canvas):
        """Rysuj detal na dużym canvas"""
        canvas.delete("all")
        
        if not self.part_data:
            return
        
        contour = self.part_data.get('contour', [])
        if len(contour) < 3:
            return
        
        canvas.update_idletasks()
        canvas_w = canvas.winfo_width() - 40
        canvas_h = canvas.winfo_height() - 80
        
        if canvas_w <= 0 or canvas_h <= 0:
            return
        
        width = self.part_data.get('width', 100)
        height = self.part_data.get('height', 100)
        
        scale_x = canvas_w / width if width > 0 else 1
        scale_y = canvas_h / height if height > 0 else 1
        scale = min(scale_x, scale_y) * 0.9
        
        offset_x = (canvas_w - width * scale) / 2 + 20
        offset_y = (canvas_h - height * scale) / 2 + 20
        
        # Siatka
        grid_step = 10
        grid_scale = grid_step * scale
        if grid_scale > 5:
            for gx in range(0, int(width) + 1, grid_step):
                x = offset_x + gx * scale
                canvas.create_line(x, offset_y, x, offset_y + height * scale, fill="#333333", width=1)
            for gy in range(0, int(height) + 1, grid_step):
                y = offset_y + (height - gy) * scale
                canvas.create_line(offset_x, y, offset_x + width * scale, y, fill="#333333", width=1)
        
        # Kontur
        points = []
        for x, y in contour:
            cx = offset_x + x * scale
            cy = offset_y + (height - y) * scale
            points.extend([cx, cy])
        
        canvas.create_polygon(points, fill=self.part_color, outline="#ffffff", width=2)
        
        # Otwory
        for hole in self.part_data.get('holes', []):
            if len(hole) >= 3:
                hole_points = []
                for x, y in hole:
                    hx = offset_x + x * scale
                    hy = offset_y + (height - y) * scale
                    hole_points.extend([hx, hy])
                canvas.create_polygon(hole_points, fill="#1a1a1a", outline="#888888", width=1)
        
        name = self.part_data.get('name', 'Detal')
        canvas.create_text(canvas_w // 2 + 20, 30, text=name, fill="#ffffff", font=("Arial", 14, "bold"))
        
        dims_text = f"Wymiary: {width:.2f} x {height:.2f} mm"
        canvas.create_text(canvas_w // 2 + 20, canvas_h + 50, text=dims_text, fill="#aaaaaa", font=("Arial", 12))
    
    def set_part(self, part_data: Optional[dict], color: str = "#3B82F6"):
        """Ustaw detal do wyświetlenia"""
        self.part_data = part_data
        self.part_color = color
        self.delete("all")
        
        if not part_data:
            self.create_text(self.winfo_reqwidth() // 2, self.winfo_reqheight() // 2,
                           text="Wybierz detal", fill="#666666", font=("Arial", 10))
            return
        
        contour = part_data.get('contour', [])
        if len(contour) < 3:
            self.create_text(self.winfo_reqwidth() // 2, self.winfo_reqheight() // 2,
                           text="Brak konturu", fill="#666666", font=("Arial", 10))
            return
        
        canvas_w = self.winfo_reqwidth() - 20
        canvas_h = self.winfo_reqheight() - 20
        
        width = part_data.get('width', 100)
        height = part_data.get('height', 100)
        
        scale_x = canvas_w / width if width > 0 else 1
        scale_y = canvas_h / height if height > 0 else 1
        scale = min(scale_x, scale_y) * 0.85
        
        offset_x = (canvas_w - width * scale) / 2 + 10
        offset_y = (canvas_h - height * scale) / 2 + 10
        
        points = []
        for x, y in contour:
            cx = offset_x + x * scale
            cy = offset_y + (height - y) * scale
            points.extend([cx, cy])
        
        self.create_polygon(points, fill=color, outline="#ffffff", width=1.5)
        
        for hole in part_data.get('holes', []):
            if len(hole) >= 3:
                hole_points = []
                for x, y in hole:
                    hx = offset_x + x * scale
                    hy = offset_y + (height - y) * scale
                    hole_points.extend([hx, hy])
                self.create_polygon(hole_points, fill="#1a1a1a", outline="#666666", width=1)
        
        dims_text = f"{width:.1f} x {height:.1f} mm"
        self.create_text(canvas_w // 2 + 10, canvas_h - 5, text=dims_text, fill="#888888", font=("Arial", 8))


# ============================================================
# Single Sheet Canvas (jeden arkusz)
# ============================================================

class SheetCanvas(Canvas):
    """Canvas dla pojedynczego arkusza z zoom i interakcją"""
    
    def __init__(self, parent, sheet_index: int, sheet_width: float, sheet_height: float,
                 on_part_click: Optional[Callable] = None, **kwargs):
        super().__init__(parent, bg="#1a1a1a", highlightthickness=1,
                        highlightbackground="#444444", **kwargs)
        
        self.sheet_index = sheet_index
        self.sheet_width = sheet_width
        self.sheet_height = sheet_height
        self.placed_parts: List[Any] = []
        self.part_colors: Dict[str, str] = {}
        
        self.zoom_scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.is_panning = False
        self.last_x = 0
        self.last_y = 0
        
        self.on_part_click = on_part_click
        self.selected_part_name: Optional[str] = None
        
        # Binds
        self.bind("<ButtonPress-1>", self._on_click)
        self.bind("<ButtonPress-2>", self._start_pan)
        self.bind("<ButtonPress-3>", self._start_pan)
        self.bind("<B2-Motion>", self._pan)
        self.bind("<B3-Motion>", self._pan)
        self.bind("<ButtonRelease-2>", self._end_pan)
        self.bind("<ButtonRelease-3>", self._end_pan)
        self.bind("<MouseWheel>", self._zoom)
        self.bind("<Button-4>", lambda e: self._zoom(e, 1.1))
        self.bind("<Button-5>", lambda e: self._zoom(e, 0.9))
        self.bind("<Configure>", self._on_resize)
    
    def _on_click(self, event):
        """Obsłuż kliknięcie - znajdź detal"""
        if not self.placed_parts:
            return
        
        sheet_x, sheet_y = self._from_canvas(event.x, event.y)
        
        for i in range(len(self.placed_parts) - 1, -1, -1):
            part = self.placed_parts[i]
            if self._point_in_part(sheet_x, sheet_y, part):
                self.selected_part_name = part.name if hasattr(part, 'name') else None
                self.redraw()
                
                if self.on_part_click:
                    self.on_part_click(self.sheet_index, part)
                break
    
    def _from_canvas(self, cx: float, cy: float) -> Tuple[float, float]:
        x = (cx - self.offset_x) / self.zoom_scale
        y = self.sheet_height - (cy - self.offset_y) / self.zoom_scale
        return x, y
    
    def _point_in_part(self, x: float, y: float, part) -> bool:
        contour = part.get_placed_contour() if hasattr(part, 'get_placed_contour') else []
        if len(contour) < 3:
            px = part.x if hasattr(part, 'x') else 0
            py = part.y if hasattr(part, 'y') else 0
            pw = part.width if hasattr(part, 'width') else 0
            ph = part.height if hasattr(part, 'height') else 0
            return px <= x <= px + pw and py <= y <= py + ph
        
        n = len(contour)
        inside = False
        j = n - 1
        for i in range(n):
            xi, yi = contour[i]
            xj, yj = contour[j]
            if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
                inside = not inside
            j = i
        return inside
    
    def select_part_by_name(self, part_name: str):
        """Zaznacz detal po nazwie"""
        self.selected_part_name = part_name
        self.redraw()
    
    def clear_selection(self):
        """Wyczyść zaznaczenie"""
        self.selected_part_name = None
        self.redraw()
    
    def set_parts(self, parts: List[Any], colors: Dict[str, str]):
        """Ustaw detale"""
        self.placed_parts = parts
        self.part_colors = colors
        # Upewnij się że canvas ma właściwe wymiary przed fit_view
        self.update_idletasks()
        self._fit_view()
        self.redraw()
        # Ponownie dopasuj widok po pełnym renderingu
        self.after(50, lambda: (self._fit_view(), self.redraw()))
    
    def _fit_view(self):
        canvas_w = self.winfo_width() or 300
        canvas_h = self.winfo_height() or 200
        
        scale_x = (canvas_w - 20) / self.sheet_width
        scale_y = (canvas_h - 20) / self.sheet_height
        self.zoom_scale = min(scale_x, scale_y)
        
        self.offset_x = (canvas_w - self.sheet_width * self.zoom_scale) / 2
        self.offset_y = (canvas_h - self.sheet_height * self.zoom_scale) / 2
    
    def _to_canvas(self, x: float, y: float) -> Tuple[float, float]:
        cx = self.offset_x + x * self.zoom_scale
        cy = self.offset_y + (self.sheet_height - y) * self.zoom_scale
        return cx, cy
    
    def _start_pan(self, event):
        self.is_panning = True
        self.last_x = event.x
        self.last_y = event.y
    
    def _pan(self, event):
        if not self.is_panning:
            return
        dx = event.x - self.last_x
        dy = event.y - self.last_y
        self.offset_x += dx
        self.offset_y += dy
        self.last_x = event.x
        self.last_y = event.y
        self.redraw()
    
    def _end_pan(self, event):
        self.is_panning = False
    
    def _zoom(self, event, factor=None):
        if factor is None:
            factor = 1.1 if event.delta > 0 else 0.9
        
        old_scale = self.zoom_scale
        self.zoom_scale = max(0.05, min(self.zoom_scale * factor, 50))
        
        mouse_x = event.x
        mouse_y = event.y
        
        self.offset_x = mouse_x - (mouse_x - self.offset_x) * (self.zoom_scale / old_scale)
        self.offset_y = mouse_y - (mouse_y - self.offset_y) * (self.zoom_scale / old_scale)
        
        self.redraw()
    
    def zoom_in(self):
        """Powiększ widok (Zoom In)"""
        self.zoom_scale = min(self.zoom_scale * 1.2, 50)
        self.redraw()

    def zoom_out(self):
        """Pomniejsz widok (Zoom Out)"""
        self.zoom_scale = max(self.zoom_scale / 1.2, 0.05)
        self.redraw()

    def zoom_all(self):
        """Dopasuj widok do arkusza (Zoom All)"""
        self._fit_view()
        self.redraw()

    def zoom_fit(self):
        """Alias dla zoom_all (zgodność z CAD)"""
        self.zoom_all()

    def _on_resize(self, event):
        if not self.placed_parts:
            self._fit_view()
        self.redraw()

    def redraw(self):
        self.delete("all")
        
        # Ramka arkusza
        x1, y1 = self._to_canvas(0, 0)
        x2, y2 = self._to_canvas(self.sheet_width, self.sheet_height)
        
        self.create_rectangle(x1, y2, x2, y1, outline="#ffffff", width=2, fill="#2a2a2a")
        
        # Siatka
        grid_step = 100
        for gx in range(0, int(self.sheet_width) + 1, grid_step):
            cx, _ = self._to_canvas(gx, 0)
            _, cy1 = self._to_canvas(0, 0)
            _, cy2 = self._to_canvas(0, self.sheet_height)
            self.create_line(cx, cy1, cx, cy2, fill="#333333", width=1)
        
        for gy in range(0, int(self.sheet_height) + 1, grid_step):
            _, cy = self._to_canvas(0, gy)
            cx1, _ = self._to_canvas(0, 0)
            cx2, _ = self._to_canvas(self.sheet_width, 0)
            self.create_line(cx1, cy, cx2, cy, fill="#333333", width=1)
        
        # Detale
        for part in self.placed_parts:
            self._draw_part(part)
        
        # Numer arkusza
        self.create_text(x1 + 10, y2 + 15, text=f"Arkusz #{self.sheet_index + 1}",
                        fill="#888888", anchor="nw", font=("Arial", 10, "bold"))
    
    def _draw_part(self, part):
        name = part.name if hasattr(part, 'name') else ''
        color = self.part_colors.get(name, "#3B82F6")
        
        is_selected = (name == self.selected_part_name)
        outline_color = "#ffff00" if is_selected else "#ffffff"
        outline_width = 3 if is_selected else 1
        
        contour = part.get_placed_contour() if hasattr(part, 'get_placed_contour') else []
        
        if len(contour) >= 3:
            canvas_points = []
            for x, y in contour:
                cx, cy = self._to_canvas(x, y)
                canvas_points.extend([cx, cy])
            
            self.create_polygon(canvas_points, fill=color, outline=outline_color, width=outline_width)
        else:
            px = part.x if hasattr(part, 'x') else 0
            py = part.y if hasattr(part, 'y') else 0
            pw = part.width if hasattr(part, 'width') else 100
            ph = part.height if hasattr(part, 'height') else 100
            
            x1, y1 = self._to_canvas(px, py)
            x2, y2 = self._to_canvas(px + pw, py + ph)
            
            self.create_rectangle(x1, y1, x2, y2, fill=color, outline=outline_color, width=outline_width)
        
        # Otwory
        if hasattr(part, 'get_placed_holes'):
            for hole in part.get_placed_holes():
                if len(hole) >= 3:
                    hole_points = []
                    for x, y in hole:
                        cx, cy = self._to_canvas(x, y)
                        hole_points.extend([cx, cy])
                    self.create_polygon(hole_points, fill="#2a2a2a", outline="#666666", width=1)

    def export_to_image(self, width: int = 800, height: int = 600) -> bytes:
        """Eksportuj arkusz do obrazu PNG jako bytes"""
        try:
            from PIL import Image, ImageDraw

            # Oblicz skale dla eksportu
            scale_x = (width - 40) / self.sheet_width
            scale_y = (height - 40) / self.sheet_height
            export_scale = min(scale_x, scale_y)
            export_offset_x = (width - self.sheet_width * export_scale) / 2
            export_offset_y = (height - self.sheet_height * export_scale) / 2

            def to_export(x: float, y: float):
                ex = export_offset_x + x * export_scale
                ey = export_offset_y + (self.sheet_height - y) * export_scale
                return int(ex), int(ey)

            # Stworz obraz
            img = Image.new('RGB', (width, height), color=(26, 26, 26))
            draw = ImageDraw.Draw(img)

            # Ramka arkusza
            x1, y1 = to_export(0, 0)
            x2, y2 = to_export(self.sheet_width, self.sheet_height)
            draw.rectangle([x1, y2, x2, y1], outline='white', width=2, fill=(42, 42, 42))

            # Siatka
            grid_step = 100
            for gx in range(0, int(self.sheet_width) + 1, grid_step):
                cx, _ = to_export(gx, 0)
                _, cy1 = to_export(0, 0)
                _, cy2 = to_export(0, self.sheet_height)
                draw.line([(cx, cy1), (cx, cy2)], fill=(51, 51, 51), width=1)

            for gy in range(0, int(self.sheet_height) + 1, grid_step):
                _, cy = to_export(0, gy)
                cx1, _ = to_export(0, 0)
                cx2, _ = to_export(self.sheet_width, 0)
                draw.line([(cx1, cy), (cx2, cy)], fill=(51, 51, 51), width=1)

            # Detale
            for part in self.placed_parts:
                name = part.name if hasattr(part, 'name') else ''
                color_hex = self.part_colors.get(name, "#3B82F6")
                # Konwersja hex na RGB
                color = tuple(int(color_hex.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))

                contour = part.get_placed_contour() if hasattr(part, 'get_placed_contour') else []

                if len(contour) >= 3:
                    points = [to_export(x, y) for x, y in contour]
                    draw.polygon(points, fill=color, outline='white')
                else:
                    px = part.x if hasattr(part, 'x') else 0
                    py = part.y if hasattr(part, 'y') else 0
                    pw = part.width if hasattr(part, 'width') else 100
                    ph = part.height if hasattr(part, 'height') else 100

                    ex1, ey1 = to_export(px, py)
                    ex2, ey2 = to_export(px + pw, py + ph)
                    draw.rectangle([ex1, ey1, ex2, ey2], fill=color, outline='white')

                # Otwory
                if hasattr(part, 'get_placed_holes'):
                    for hole in part.get_placed_holes():
                        if len(hole) >= 3:
                            hole_points = [to_export(x, y) for x, y in hole]
                            draw.polygon(hole_points, fill=(42, 42, 42), outline=(102, 102, 102))

            # Numer arkusza
            try:
                from PIL import ImageFont
                font = ImageFont.load_default()
                draw.text((x1 + 10, y2 + 5), f"Arkusz #{self.sheet_index + 1}",
                         fill=(136, 136, 136), font=font)
            except:
                pass

            # Zapisz do bytes
            import io
            buffer = io.BytesIO()
            img.save(buffer, format='PNG')
            return buffer.getvalue()

        except ImportError as e:
            logger.error(f"PIL not available for image export: {e}")
            return b''
        except Exception as e:
            logger.error(f"Error exporting sheet to image: {e}")
            return b''


# ============================================================
# Multi-Sheet Scrollable View
# ============================================================

class MultiSheetView(ctk.CTkFrame):
    """Przewijalna lista arkuszy wyświetlanych obok siebie"""

    def __init__(self, parent, sheet_width: float, sheet_height: float,
                 on_part_click: Optional[Callable] = None):
        super().__init__(parent, fg_color="transparent")

        self.sheet_width = sheet_width
        self.sheet_height = sheet_height
        self.on_part_click = on_part_click

        self.sheet_canvases: List[SheetCanvas] = []
        self.part_colors: Dict[str, str] = {}
        self.canvas_frames: List[ctk.CTkFrame] = []
        self.sheets_data: List[Any] = []
        self.all_parts: List[dict] = []

        self._setup_ui()

    def _setup_ui(self):
        # Scrollable frame dla arkuszy
        self.scroll_frame = ctk.CTkScrollableFrame(self, fg_color="#1a1a1a",
                                                    orientation="horizontal")
        self.scroll_frame.pack(fill="both", expand=True)

        # Binduj resize do aktualizacji wysokości canvasów
        self.bind("<Configure>", self._on_resize)
    
    def set_results(self, sheets: List[Any], colors: Dict[str, str], all_parts: List[dict] = None):
        """Ustaw wyniki nestingu (wiele arkuszy)"""
        self.part_colors = colors
        self.sheets_data = sheets
        self.all_parts = all_parts or []

        # Usuń stare canvas
        for canvas in self.sheet_canvases:
            canvas.destroy()
        self.sheet_canvases.clear()
        self.canvas_frames.clear()

        # Usuń stare frame'y
        for widget in self.scroll_frame.winfo_children():
            widget.destroy()

        # Oblicz dostępną wysokość dynamicznie
        self.update_idletasks()  # Upewnij się, że rozmiar jest aktualny
        available_height = self.winfo_height()

        # Jeśli jeszcze nie ma rozmiaru (pierwsze wywołanie), użyj domyślnej wartości
        if available_height <= 1:
            canvas_height = 400
        else:
            # Odejmij miejsce na padding i scroll bar
            canvas_height = max(200, available_height - 60)

        # Utwórz canvas dla każdego arkusza
        for i, sheet in enumerate(sheets):
            # Oblicz szerokość canvas proporcjonalnie do wysokości
            aspect = self.sheet_height / self.sheet_width if self.sheet_width > 0 else 0.5
            canvas_width = int(canvas_height / aspect) if aspect > 0 else 400
            canvas_width = min(canvas_width, 800)  # Max szerokość zwiększona z 600 na 800
            
            frame = ctk.CTkFrame(self.scroll_frame, fg_color="#252525", corner_radius=8)
            frame.pack(side="left", padx=5, pady=5)
            self.canvas_frames.append(frame)

            # Nagłówek
            header = ctk.CTkFrame(frame, fg_color="transparent", height=30)
            header.pack(fill="x", padx=5, pady=(5, 0))

            lbl_title = ctk.CTkLabel(header, text=f"Arkusz #{i+1}",
                                     font=ctk.CTkFont(size=12, weight="bold"))
            lbl_title.pack(side="left", padx=5)

            parts_count = len(sheet.placed_parts) if hasattr(sheet, 'placed_parts') else 0
            efficiency = sheet.efficiency if hasattr(sheet, 'efficiency') else 0

            lbl_info = ctk.CTkLabel(header, text=f"{parts_count} detali | {efficiency:.1%}",
                                    font=ctk.CTkFont(size=10), text_color="#888888")
            lbl_info.pack(side="right", padx=5)

            # Przycisk powiększenia
            btn_enlarge = ctk.CTkButton(header, text="🔍", width=30, height=25,
                                       fg_color=Theme.ACCENT_PRIMARY,
                                       command=lambda idx=i: self._open_sheet_detail(idx))
            btn_enlarge.pack(side="right", padx=2)
            
            # Canvas
            canvas = SheetCanvas(
                frame,
                sheet_index=i,
                sheet_width=self.sheet_width,
                sheet_height=self.sheet_height,
                on_part_click=self._handle_part_click,
                width=canvas_width,
                height=canvas_height
            )
            canvas.pack(padx=5, pady=5)
            
            # Ustaw detale
            parts = sheet.placed_parts if hasattr(sheet, 'placed_parts') else []
            canvas.set_parts(parts, colors)
            
            self.sheet_canvases.append(canvas)
    
    def _handle_part_click(self, sheet_index: int, part):
        """Obsłuż kliknięcie na detal"""
        # Zaznacz na tym arkuszu, odznacz na innych
        part_name = part.name if hasattr(part, 'name') else None
        for i, canvas in enumerate(self.sheet_canvases):
            if i == sheet_index:
                canvas.select_part_by_name(part_name)
            else:
                canvas.clear_selection()
        
        if self.on_part_click:
            self.on_part_click(sheet_index, part)
    
    def highlight_part(self, part_name: str, sheet_index: Optional[int] = None):
        """Podświetl detal po nazwie"""
        if sheet_index is not None and 0 <= sheet_index < len(self.sheet_canvases):
            # Zaznacz na konkretnym arkuszu
            for i, canvas in enumerate(self.sheet_canvases):
                if i == sheet_index:
                    canvas.select_part_by_name(part_name)
                else:
                    canvas.clear_selection()
        else:
            # Znajdź arkusz z tym detalem
            for canvas in self.sheet_canvases:
                for part in canvas.placed_parts:
                    if hasattr(part, 'name') and part.name == part_name:
                        canvas.select_part_by_name(part_name)
                        return
    
    def clear_selection(self):
        """Wyczyść zaznaczenie na wszystkich arkuszach"""
        for canvas in self.sheet_canvases:
            canvas.clear_selection()

    def _on_resize(self, event):
        """Aktualizuj wysokości canvasów przy zmianie rozmiaru"""
        # Ignoruj jeśli to nie zmiana rozmiaru całego frame'a
        if event.widget != self:
            return

        # Oblicz dostępną wysokość (odejmij margines dla scroll bara)
        available_height = self.winfo_height() - 60  # 60px zapas na scroll bar i padding

        if available_height < 100:
            return  # Za mało miejsca

        # Zaktualizuj wysokość wszystkich canvasów
        for canvas in self.sheet_canvases:
            canvas.configure(height=available_height)
            canvas._fit_view()
            canvas.redraw()

    def _open_sheet_detail(self, sheet_index: int):
        """Otwórz szczegółowe okno dla arkusza"""
        if 0 <= sheet_index < len(self.sheets_data):
            sheet_data = self.sheets_data[sheet_index]

            detail_window = SheetDetailWindow(
                self.winfo_toplevel(),
                sheet_index=sheet_index,
                sheet_data=sheet_data,
                sheet_width=self.sheet_width,
                sheet_height=self.sheet_height,
                all_parts=self.all_parts,
                part_colors=self.part_colors
            )


# ============================================================
# Sheet Detail Window (powiększone okno pojedynczego arkusza)
# ============================================================

class SheetDetailWindow(ctk.CTkToplevel):
    """Okno szczegółowe dla pojedynczego arkusza z listą detali"""

    def __init__(self, parent, sheet_index: int, sheet_data: Any,
                 sheet_width: float, sheet_height: float,
                 all_parts: List[dict], part_colors: Dict[str, str]):
        super().__init__(parent)

        self.sheet_index = sheet_index
        self.sheet_data = sheet_data
        self.sheet_width = sheet_width
        self.sheet_height = sheet_height
        self.all_parts = all_parts
        self.part_colors = part_colors

        # Konfiguracja okna - 75% rozmiaru ekranu
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        win_w = int(screen_w * 0.75)
        win_h = int(screen_h * 0.75)

        self.title(f"Arkusz #{sheet_index + 1} - Szczegóły")
        self.geometry(f"{win_w}x{win_h}")
        self.configure(fg_color=Theme.BG_DARK)

        # Wyśrodkuj okno
        x = (screen_w - win_w) // 2
        y = (screen_h - win_h) // 2
        self.geometry(f"+{x}+{y}")

        self._setup_ui()

        # Ustawienia okna
        self.attributes('-topmost', True)  # Okno na pierwszym planie
        self.focus_set()

    def _setup_ui(self):
        """Buduj interfejs okna"""
        self.grid_columnconfigure(0, weight=0)  # Lista detali
        self.grid_columnconfigure(1, weight=1)  # Canvas arkusza
        self.grid_rowconfigure(0, weight=1)

        # === LEWY PANEL - Lista detali ===
        left_panel = ctk.CTkFrame(self, fg_color=Theme.BG_CARD, width=350)
        left_panel.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        left_panel.grid_propagate(False)

        # Nagłówek
        placed_parts = self.sheet_data.placed_parts if hasattr(self.sheet_data, 'placed_parts') else []
        efficiency = self.sheet_data.efficiency if hasattr(self.sheet_data, 'efficiency') else 0

        title = ctk.CTkLabel(left_panel,
                            text=f"📋 Detale na arkuszu ({len(placed_parts)})",
                            font=ctk.CTkFont(size=14, weight="bold"))
        title.pack(pady=(10, 5), padx=10, anchor="w")

        stats_text = f"Efektywność: {efficiency:.1%}"
        stats_label = ctk.CTkLabel(left_panel, text=stats_text,
                                   font=ctk.CTkFont(size=11), text_color=Theme.ACCENT_INFO)
        stats_label.pack(pady=(0, 10), padx=10, anchor="w")

        # Wyszukiwarka
        search_frame = ctk.CTkFrame(left_panel, fg_color="transparent")
        search_frame.pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(search_frame, text="🔍 Szukaj:",
                    font=ctk.CTkFont(size=11)).pack(side="left", padx=(0, 5))

        self.search_entry = ctk.CTkEntry(search_frame, placeholder_text="nazwa detalu...")
        self.search_entry.pack(side="left", fill="x", expand=True)
        self.search_entry.bind("<KeyRelease>", self._on_search)

        # Lista detali
        tree_frame = ctk.CTkFrame(left_panel, fg_color="transparent")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)

        # Style
        style = ttk.Style()
        style.configure("DetailWindow.Treeview", background="#1a1a1a",
                       foreground="white", fieldbackground="#1a1a1a", rowheight=30)
        style.map("DetailWindow.Treeview", background=[("selected", "#8b5cf6")])

        self.tree = ttk.Treeview(tree_frame, columns=("name", "dims", "position"),
                                show="headings", height=15, style="DetailWindow.Treeview")
        self.tree.heading("name", text="Nazwa")
        self.tree.heading("dims", text="Wymiary")
        self.tree.heading("position", text="Pozycja (x, y)")
        self.tree.column("name", width=140)
        self.tree.column("dims", width=80, anchor="center")
        self.tree.column("position", width=100, anchor="center")

        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Wypełnij listę
        for i, part in enumerate(placed_parts):
            name = part.name if hasattr(part, 'name') else f'Part_{i}'
            w = part.width if hasattr(part, 'width') else 0
            h = part.height if hasattr(part, 'height') else 0
            px = part.x if hasattr(part, 'x') else 0
            py = part.y if hasattr(part, 'y') else 0

            dims = f"{w:.0f}×{h:.0f}"
            pos = f"({px:.0f}, {py:.0f})"

            self.tree.insert("", "end", iid=f"part_{i}",
                           values=(name, dims, pos))

        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # Podgląd detalu
        preview_label = ctk.CTkLabel(left_panel, text="Podgląd detalu",
                                     font=ctk.CTkFont(size=12))
        preview_label.pack(pady=(10, 5), padx=10, anchor="w")

        self.part_preview = PartPreviewCanvas(left_panel, width=310, height=180)
        self.part_preview.pack(padx=10, pady=5)

        self.lbl_part_info = ctk.CTkLabel(left_panel, text="Wybierz detal z listy",
                                         font=ctk.CTkFont(size=10),
                                         text_color=Theme.TEXT_MUTED)
        self.lbl_part_info.pack(pady=5)

        # === PRAWY PANEL - Canvas arkusza ===
        right_panel = ctk.CTkFrame(self, fg_color=Theme.BG_CARD)
        right_panel.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)

        # Toolbar
        toolbar = ctk.CTkFrame(right_panel, fg_color="transparent", height=50)
        toolbar.pack(fill="x", padx=10, pady=10)

        lbl_title = ctk.CTkLabel(toolbar,
                                text=f"Arkusz #{self.sheet_index + 1}",
                                font=ctk.CTkFont(size=16, weight="bold"))
        lbl_title.pack(side="left", padx=10)

        lbl_dims = ctk.CTkLabel(toolbar,
                               text=f"{self.sheet_width:.0f} × {self.sheet_height:.0f} mm",
                               font=ctk.CTkFont(size=12), text_color=Theme.TEXT_SECONDARY)
        lbl_dims.pack(side="left", padx=10)

        # Przyciski zoom
        btn_zoom_in = ctk.CTkButton(toolbar, text="🔍+", width=40, height=40,
                                   font=ctk.CTkFont(size=16),
                                   command=self._zoom_in,
                                   fg_color=Theme.BG_INPUT,
                                   hover_color=Theme.ACCENT_PRIMARY)
        btn_zoom_in.pack(side="left", padx=2)
        self._create_tooltip(btn_zoom_in, "Powiększ (Zoom In)")

        btn_zoom_out = ctk.CTkButton(toolbar, text="🔍−", width=40, height=40,
                                    font=ctk.CTkFont(size=16),
                                    command=self._zoom_out,
                                    fg_color=Theme.BG_INPUT,
                                    hover_color=Theme.ACCENT_PRIMARY)
        btn_zoom_out.pack(side="left", padx=2)
        self._create_tooltip(btn_zoom_out, "Pomniejsz (Zoom Out)")

        btn_zoom_all = ctk.CTkButton(toolbar, text="⊡", width=40, height=40,
                                    font=ctk.CTkFont(size=18),
                                    command=self._zoom_all,
                                    fg_color=Theme.BG_INPUT,
                                    hover_color=Theme.ACCENT_PRIMARY)
        btn_zoom_all.pack(side="left", padx=2)
        self._create_tooltip(btn_zoom_all, "Dopasuj widok (Zoom All)")

        btn_zoom_fit = ctk.CTkButton(toolbar, text="⊞", width=40, height=40,
                                    font=ctk.CTkFont(size=18),
                                    command=self._zoom_fit,
                                    fg_color=Theme.BG_INPUT,
                                    hover_color=Theme.ACCENT_PRIMARY)
        btn_zoom_fit.pack(side="left", padx=2)
        self._create_tooltip(btn_zoom_fit, "Dopasuj do arkusza (Zoom Fit)")

        btn_close = ctk.CTkButton(toolbar, text="✕ Zamknij",
                                 command=self.destroy, width=100,
                                 fg_color=Theme.ACCENT_DANGER)
        btn_close.pack(side="right", padx=5)

        # Canvas
        canvas_frame = ctk.CTkFrame(right_panel, fg_color="#1a1a1a")
        canvas_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.sheet_canvas = SheetCanvas(
            canvas_frame,
            sheet_index=self.sheet_index,
            sheet_width=self.sheet_width,
            sheet_height=self.sheet_height,
            on_part_click=self._on_canvas_part_click
        )
        self.sheet_canvas.pack(fill="both", expand=True, padx=5, pady=5)

        # Ustaw detale
        self.sheet_canvas.set_parts(placed_parts, self.part_colors)

        # Wywołaj Zoom All po załadowaniu arkusza (gwarantuje prawidłowe dopasowanie)
        self.after(150, self._zoom_all)

    def _on_search(self, event):
        """Filtruj listę detali według wyszukiwanego tekstu"""
        search_text = self.search_entry.get().lower()

        # Wyczyść listę
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Odfiltruj i dodaj ponownie
        placed_parts = self.sheet_data.placed_parts if hasattr(self.sheet_data, 'placed_parts') else []
        for i, part in enumerate(placed_parts):
            name = part.name if hasattr(part, 'name') else f'Part_{i}'

            if search_text in name.lower():
                w = part.width if hasattr(part, 'width') else 0
                h = part.height if hasattr(part, 'height') else 0
                px = part.x if hasattr(part, 'x') else 0
                py = part.y if hasattr(part, 'y') else 0

                dims = f"{w:.0f}×{h:.0f}"
                pos = f"({px:.0f}, {py:.0f})"

                self.tree.insert("", "end", iid=f"part_{i}",
                               values=(name, dims, pos))

    def _on_tree_select(self, event):
        """Obsłuż wybór detalu z listy"""
        selection = self.tree.selection()
        if not selection:
            return

        try:
            item = selection[0]
            idx = int(item.split("_")[1])

            placed_parts = self.sheet_data.placed_parts if hasattr(self.sheet_data, 'placed_parts') else []
            if 0 <= idx < len(placed_parts):
                part = placed_parts[idx]
                name = part.name if hasattr(part, 'name') else ''

                # Znajdź dane detalu w oryginalnej liście
                part_data = None
                for p in self.all_parts:
                    if p.get('name', '') == name:
                        part_data = p
                        break

                if part_data:
                    color = self.part_colors.get(name, "#3B82F6")
                    self.part_preview.set_part(part_data, color)

                    w = part_data.get('width', 0)
                    h = part_data.get('height', 0)
                    px = part.x if hasattr(part, 'x') else 0
                    py = part.y if hasattr(part, 'y') else 0

                    self.lbl_part_info.configure(
                        text=f"{name}\n{w:.1f} × {h:.1f} mm\nPozycja: ({px:.0f}, {py:.0f})"
                    )

                # Podświetl na canvasie
                self.sheet_canvas.select_part_by_name(name)
        except Exception as e:
            logger.error(f"Error in tree select: {e}")

    def _on_canvas_part_click(self, sheet_index: int, part):
        """Obsłuż kliknięcie na detal na canvasie"""
        placed_parts = self.sheet_data.placed_parts if hasattr(self.sheet_data, 'placed_parts') else []

        for i, p in enumerate(placed_parts):
            if p == part:
                item_id = f"part_{i}"
                self.tree.selection_set(item_id)
                self.tree.focus(item_id)
                self.tree.see(item_id)
                break

    def _zoom_in(self):
        """Obsługa przycisku Zoom In"""
        self.sheet_canvas.zoom_in()

    def _zoom_out(self):
        """Obsługa przycisku Zoom Out"""
        self.sheet_canvas.zoom_out()

    def _zoom_all(self):
        """Obsługa przycisku Zoom All"""
        self.sheet_canvas.zoom_all()

    def _zoom_fit(self):
        """Obsługa przycisku Zoom Fit"""
        self.sheet_canvas.zoom_fit()

    def _create_tooltip(self, widget, text):
        """Tworzy tooltip dla widgetu"""
        import tkinter as tk

        def on_enter(event):
            tooltip = tk.Toplevel()
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{event.x_root + 10}+{event.y_root + 10}")

            label = tk.Label(
                tooltip,
                text=text,
                background="#333333",
                foreground="#ffffff",
                relief="solid",
                borderwidth=1,
                font=("Helvetica", 9),
                padx=8,
                pady=4
            )
            label.pack()

            widget._tooltip = tooltip

        def on_leave(event):
            if hasattr(widget, '_tooltip'):
                widget._tooltip.destroy()
                del widget._tooltip

        widget.bind('<Enter>', on_enter)
        widget.bind('<Leave>', on_leave)


# ============================================================
# Single Nesting Tab
# ============================================================

class NestingTab(ctk.CTkFrame):
    """Pojedyncza zakładka nestingu dla kombinacji materiał+grubość"""
    
    def __init__(self, parent, material: str, thickness: float, 
                 parts: List[dict], sheet_formats: List[Tuple[float, float]],
                 on_nesting_complete: Optional[Callable] = None):
        super().__init__(parent, fg_color=Theme.BG_DARK)
        
        self.material = material
        self.thickness = thickness
        self.parts = parts
        self.sheet_formats = sheet_formats
        self.on_nesting_complete = on_nesting_complete
        
        self.nester = None
        self.nesting_result = None
        self.nesting_thread = None
        
        # Mapowanie nazwa -> kolor
        self.part_colors: Dict[str, str] = {}
        for i, p in enumerate(parts):
            name = p.get('name', f'Part_{i}')
            self.part_colors[name] = PART_COLORS[i % len(PART_COLORS)]
        
        # Śledzenie statusu detali
        self.placed_parts_names: Set[str] = set()
        self.unplaced_parts_names: Set[str] = set()
        
        # Mapowanie nazwa -> sheet_index (dla znalezionych detali)
        self.part_sheet_map: Dict[str, int] = {}
        
        self._setup_ui()
    
    def _setup_ui(self):
        """Buduj interfejs zakładki"""
        self.grid_columnconfigure(0, weight=0)  # Lista detali
        self.grid_columnconfigure(1, weight=1)  # Arkusze
        self.grid_rowconfigure(0, weight=1)
        
        # === LEWY PANEL ===
        left_panel = ctk.CTkFrame(self, fg_color=Theme.BG_CARD, width=320)
        left_panel.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        left_panel.grid_propagate(False)
        
        # Tytuł
        title = ctk.CTkLabel(left_panel, text=f"📋 Detale ({len(self.parts)})",
                            font=ctk.CTkFont(size=14, weight="bold"))
        title.pack(pady=(10, 5), padx=10, anchor="w")
        
        # Lista detali
        tree_frame = ctk.CTkFrame(left_panel, fg_color="transparent")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Style dla kolorów tła
        style = ttk.Style()
        style.configure("Treeview", background="#1a1a1a", foreground="white",
                       fieldbackground="#1a1a1a", rowheight=25)
        style.map("Treeview", background=[("selected", "#8b5cf6")])
        
        self.tree = ttk.Treeview(tree_frame, columns=("name", "dims", "qty", "status"),
                                  show="headings", height=12)
        self.tree.heading("name", text="Nazwa")
        self.tree.heading("dims", text="Wymiary")
        self.tree.heading("qty", text="Ilość")
        self.tree.heading("status", text="Status")
        self.tree.column("name", width=120)
        self.tree.column("dims", width=70, anchor="center")
        self.tree.column("qty", width=40, anchor="center")
        self.tree.column("status", width=50, anchor="center")
        
        # Tagi dla kolorów
        self.tree.tag_configure("placed", background="#1c3a1c")
        self.tree.tag_configure("unplaced", background="#4a1c1c")
        self.tree.tag_configure("pending", background="#1a1a1a")
        
        self.tree.pack(fill="both", expand=True)
        
        # Wypełnij listę
        for i, p in enumerate(self.parts):
            name = p.get('name', f'Part_{i}')
            dims = f"{p.get('width', 0):.0f}x{p.get('height', 0):.0f}"
            qty = p.get('quantity', 1)
            self.tree.insert("", "end", iid=f"part_{i}", values=(name, dims, qty, "⏳"), tags=("pending",))
        
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        self.tree.bind("<Double-1>", self._edit_quantity)
        
        # Podgląd detalu
        preview_label = ctk.CTkLabel(left_panel, text="Podgląd detalu",
                                     font=ctk.CTkFont(size=12))
        preview_label.pack(pady=(10, 5), padx=10, anchor="w")
        
        self.part_preview = PartPreviewCanvas(left_panel, width=280, height=150)
        self.part_preview.pack(padx=10, pady=5)
        
        self.lbl_part_info = ctk.CTkLabel(left_panel, text="Wybierz detal z listy",
                                          font=ctk.CTkFont(size=10), text_color=Theme.TEXT_MUTED)
        self.lbl_part_info.pack(pady=5)
        
        # === PRAWY PANEL ===
        right_panel = ctk.CTkFrame(self, fg_color=Theme.BG_CARD)
        right_panel.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        
        # Toolbar
        toolbar = ctk.CTkFrame(right_panel, fg_color="transparent", height=50)
        toolbar.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(toolbar, text="Format arkusza:").pack(side="left", padx=(0, 5))
        
        format_values = [f"{int(f[0])}x{int(f[1])}" for f in self.sheet_formats]
        self.format_var = ctk.StringVar(value=format_values[0] if format_values else "3000x1500")
        self.format_combo = ctk.CTkComboBox(toolbar, values=format_values,
                                            variable=self.format_var, width=120)
        self.format_combo.pack(side="left", padx=5)
        
        ctk.CTkLabel(toolbar, text="Odstęp:").pack(side="left", padx=(20, 5))
        self.spacing_entry = ctk.CTkEntry(toolbar, width=50)
        self.spacing_entry.insert(0, "5")
        self.spacing_entry.pack(side="left", padx=5)
        ctk.CTkLabel(toolbar, text="mm").pack(side="left")
        
        self.deep_var = ctk.BooleanVar(value=True)
        self.deep_check = ctk.CTkCheckBox(toolbar, text="🔬 Głęboka analiza",
                                          variable=self.deep_var)
        self.deep_check.pack(side="left", padx=20)
        
        self.btn_start = ctk.CTkButton(toolbar, text="▶ Start Nesting",
                                       command=self.start_nesting,
                                       fg_color=Theme.ACCENT_SUCCESS, width=120)
        self.btn_start.pack(side="right", padx=5)
        
        self.btn_export = ctk.CTkButton(toolbar, text="💾 Eksport DXF",
                                        command=self.export_dxf,
                                        fg_color=Theme.ACCENT_INFO, width=100,
                                        state="disabled")
        self.btn_export.pack(side="right", padx=5)
        
        # Multi-sheet view
        self.multi_sheet_view = MultiSheetView(
            right_panel,
            sheet_width=3000,
            sheet_height=1500,
            on_part_click=self._on_sheet_part_click
        )
        self.multi_sheet_view.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        # Statusbar
        status_frame = ctk.CTkFrame(right_panel, fg_color=Theme.BG_INPUT, height=50)
        status_frame.pack(fill="x", padx=10, pady=(0, 10))
        status_frame.pack_propagate(False)
        
        self.lbl_status = ctk.CTkLabel(status_frame, text="Gotowy do nestingu",
                                       font=ctk.CTkFont(size=11))
        self.lbl_status.pack(side="left", padx=10, pady=10)
        
        self.lbl_sheets = ctk.CTkLabel(status_frame, text="Arkusze: -",
                                       font=ctk.CTkFont(size=11), text_color=Theme.ACCENT_INFO)
        self.lbl_sheets.pack(side="right", padx=10, pady=10)
        
        self.lbl_efficiency = ctk.CTkLabel(status_frame, text="Efektywność: -",
                                           font=ctk.CTkFont(size=11, weight="bold"),
                                           text_color=Theme.ACCENT_PRIMARY)
        self.lbl_efficiency.pack(side="right", padx=10, pady=10)
        
        self.progress = ctk.CTkProgressBar(status_frame, width=150)
        self.progress.pack(side="right", padx=10, pady=10)
        self.progress.set(0)
    
    def _on_tree_select(self, event):
        """Obsłuż wybór detalu z listy"""
        selection = self.tree.selection()
        if not selection:
            return
        
        try:
            item = selection[0]
            idx = int(item.split("_")[1])
            
            if 0 <= idx < len(self.parts):
                part_data = self.parts[idx]
                name = part_data.get('name', '')
                color = self.part_colors.get(name, PART_COLORS[idx % len(PART_COLORS)])
                self.part_preview.set_part(part_data, color)
                
                w = part_data.get('width', 0)
                h = part_data.get('height', 0)
                
                # Status info
                if name in self.placed_parts_names:
                    sheet_idx = self.part_sheet_map.get(name, 0)
                    status_text = f"✓ Arkusz #{sheet_idx + 1}"
                elif name in self.unplaced_parts_names:
                    status_text = "✗ Nieznestowany"
                else:
                    status_text = ""
                
                self.lbl_part_info.configure(text=f"{name}\n{w:.1f} x {h:.1f} mm\n{status_text}")
                
                # Podświetl na arkuszach
                if name in self.placed_parts_names:
                    sheet_idx = self.part_sheet_map.get(name)
                    self.multi_sheet_view.highlight_part(name, sheet_idx)
                else:
                    self.multi_sheet_view.clear_selection()
                    
        except Exception as e:
            logger.error(f"Error in tree select: {e}")
    
    def _on_sheet_part_click(self, sheet_index: int, part):
        """Obsłuż kliknięcie na detal na arkuszu"""
        part_name = part.name if hasattr(part, 'name') else ''
        
        # Znajdź na liście i zaznacz
        for i, p in enumerate(self.parts):
            if p.get('name', '') == part_name:
                item_id = f"part_{i}"
                self.tree.selection_set(item_id)
                self.tree.focus(item_id)
                self.tree.see(item_id)
                
                color = self.part_colors.get(part_name, PART_COLORS[i % len(PART_COLORS)])
                self.part_preview.set_part(p, color)
                
                w = p.get('width', 0)
                h = p.get('height', 0)
                self.lbl_part_info.configure(text=f"{part_name}\n{w:.1f} x {h:.1f} mm\n✓ Arkusz #{sheet_index + 1}")
                break
    
    def _edit_quantity(self, event):
        """Edycja ilości przez podwójne kliknięcie"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item = selection[0]
        col = self.tree.identify_column(event.x)
        
        if col != "#3":
            return
        
        try:
            idx = int(item.split("_")[1])
        except:
            return
        
        x, y, w, h = self.tree.bbox(item, col)
        
        current_qty = self.parts[idx].get('quantity', 1)
        
        entry = ctk.CTkEntry(self.tree.master, width=50)
        entry.insert(0, str(current_qty))
        entry.place(x=x, y=y)
        entry.focus()
        
        def save(e=None):
            try:
                new_qty = int(entry.get())
                if new_qty > 0:
                    self.parts[idx]['quantity'] = new_qty
                    self.tree.set(item, "qty", str(new_qty))
            except:
                pass
            entry.destroy()
        
        entry.bind("<Return>", save)
        entry.bind("<FocusOut>", save)
    
    def start_nesting(self):
        """Rozpocznij nesting"""
        format_str = self.format_var.get()
        try:
            w, h = map(float, format_str.split('x'))
        except:
            w, h = 3000, 1500
        
        try:
            spacing = float(self.spacing_entry.get())
        except:
            spacing = 5.0
        
        from quotations.nesting.fast_nester import FastNester
        
        sheet_w = min(w, h)
        sheet_h = max(w, h)
        
        self.nester = FastNester(sheet_w, sheet_h, spacing)
        
        # Aktualizuj multi_sheet_view
        self.multi_sheet_view.sheet_width = sheet_w
        self.multi_sheet_view.sheet_height = sheet_h
        
        for p in self.parts:
            self.nester.add_part_from_dict(p, quantity=p.get('quantity', 1))
        
        if not self.nester.parts:
            messagebox.showerror("Błąd", "Brak detali do nestingu")
            return
        
        # Reset statusów
        self.placed_parts_names.clear()
        self.unplaced_parts_names.clear()
        self.part_sheet_map.clear()
        
        # Reset tagów na liście
        for item in self.tree.get_children():
            self.tree.item(item, tags=("pending",))
            self.tree.set(item, "status", "⏳")
        
        self.btn_start.configure(state="disabled")
        self.btn_export.configure(state="disabled")
        self.lbl_status.configure(text="Nesting w toku...")
        self.progress.set(0.1)
        
        deep = self.deep_var.get()
        
        def run():
            result = self.nester.run_nesting(callback=self._update_view, deep_analysis=deep)
            self.after(0, lambda: self._finish_nesting(result))
        
        self.nesting_thread = threading.Thread(target=run, daemon=True)
        self.nesting_thread.start()
    
    def _update_view(self, parts, efficiency: float):
        """Callback z nestera"""
        self.after(0, lambda: self._redraw(parts, efficiency))
    
    def _redraw(self, parts, efficiency: float):
        """Przerysuj podczas nestingu"""
        self.lbl_efficiency.configure(text=f"Efektywność: {efficiency:.1%}")
        self.progress.set(0.5 + efficiency * 0.5)
    
    def _finish_nesting(self, result):
        """Zakończ nesting"""
        self.nesting_result = result
        
        # Aktualizuj widok arkuszy
        if result.sheets:
            self.multi_sheet_view.set_results(result.sheets, self.part_colors, self.parts)
        
        # Zbierz informacje o statusach
        self.placed_parts_names.clear()
        self.unplaced_parts_names.clear()
        self.part_sheet_map.clear()
        
        for sheet in result.sheets:
            for part in sheet.placed_parts:
                name = part.name if hasattr(part, 'name') else ''
                self.placed_parts_names.add(name)
                self.part_sheet_map[name] = part.sheet_index if hasattr(part, 'sheet_index') else 0
        
        for up in result.unplaced_parts:
            self.unplaced_parts_names.add(up.name)
        
        # Aktualizuj listę
        for i, p in enumerate(self.parts):
            item_id = f"part_{i}"
            name = p.get('name', '')
            
            if name in self.placed_parts_names:
                sheet_idx = self.part_sheet_map.get(name, 0)
                self.tree.item(item_id, tags=("placed",))
                self.tree.set(item_id, "status", f"#{sheet_idx+1}")
            elif name in self.unplaced_parts_names:
                self.tree.item(item_id, tags=("unplaced",))
                self.tree.set(item_id, "status", "✗")
            else:
                self.tree.item(item_id, tags=("pending",))
                self.tree.set(item_id, "status", "?")
        
        self.btn_start.configure(state="normal")
        self.btn_export.configure(state="normal")
        
        # Status
        placed_count = len(result.placed_parts)
        unplaced_count = result.unplaced_count
        sheets_count = result.sheets_used
        
        status_text = f"Gotowe! {placed_count} detali na {sheets_count} arkuszach"
        if unplaced_count > 0:
            status_text += f" | ⚠️ {unplaced_count} nieznestowanych"
        
        self.lbl_status.configure(text=status_text)
        self.lbl_sheets.configure(text=f"Arkusze: {sheets_count}")
        self.lbl_efficiency.configure(text=f"Efektywność: {result.total_efficiency:.1%}")
        self.progress.set(1.0)
        
        if self.on_nesting_complete:
            self.on_nesting_complete(self.material, self.thickness, result)
    
    def export_dxf(self):
        """Eksportuj wyniki do DXF"""
        if not self.nester or not self.nester.result:
            return
        
        filepath = filedialog.asksaveasfilename(
            defaultextension=".dxf",
            filetypes=[("DXF Files", "*.dxf")],
            initialfile=f"nesting_{self.material}_{self.thickness}mm.dxf"
        )
        
        if filepath:
            saved = self.nester.export_all_dxf(filepath)
            if saved:
                messagebox.showinfo("Sukces", f"Zapisano {len(saved)} plików:\n" + "\n".join(os.path.basename(f) for f in saved))
            else:
                messagebox.showerror("Błąd", "Nie udało się zapisać plików")

    def export_images(self, width: int = 800, height: int = 600) -> List[bytes]:
        """Eksportuj wszystkie arkusze jako obrazy PNG (bytes)"""
        images = []
        if hasattr(self, 'multi_sheet_view') and self.multi_sheet_view:
            for canvas in self.multi_sheet_view.sheet_canvases:
                img_bytes = canvas.export_to_image(width, height)
                if img_bytes:
                    images.append(img_bytes)
        return images

    def get_result(self):
        return self.nesting_result


# ============================================================
# Main Tabs Panel
# ============================================================

class NestingTabsPanel(ctk.CTkFrame):
    """Panel z zakładkami nestingu dla każdej kombinacji materiał+grubość"""
    
    def __init__(self, parent, parts_by_group: Dict[Tuple[str, float], List[dict]],
                 sheet_formats: List[Tuple[float, float]] = None,
                 on_all_complete: Optional[Callable] = None):
        super().__init__(parent, fg_color=Theme.BG_DARK)
        
        self.parts_by_group = parts_by_group
        self.sheet_formats = sheet_formats or [
            (3000, 1500), (2500, 1250), (2000, 1000), (1500, 750)
        ]
        self.on_all_complete = on_all_complete
        
        self.tabs: Dict[str, NestingTab] = {}
        self.results: Dict[Tuple[str, float], Any] = {}
        
        self._setup_ui()
    
    def _setup_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        self.tabview = ctk.CTkTabview(self, fg_color=Theme.BG_CARD)
        self.tabview.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        
        for (material, thickness), parts in self.parts_by_group.items():
            tab_name = f"{material} {thickness}mm"
            
            self.tabview.add(tab_name)
            tab_frame = self.tabview.tab(tab_name)
            
            tab = NestingTab(
                tab_frame,
                material=material,
                thickness=thickness,
                parts=parts,
                sheet_formats=self.sheet_formats,
                on_nesting_complete=self._on_tab_complete
            )
            tab.pack(fill="both", expand=True)
            
            self.tabs[tab_name] = tab
        
        if not self.parts_by_group:
            empty_label = ctk.CTkLabel(
                self.tabview,
                text="Brak detali do nestingu.\nDodaj pliki DXF.",
                font=ctk.CTkFont(size=14),
                text_color=Theme.TEXT_MUTED
            )
            empty_label.pack(expand=True)
    
    def _on_tab_complete(self, material: str, thickness: float, result):
        self.results[(material, thickness)] = result
        
        if len(self.results) == len(self.parts_by_group):
            if self.on_all_complete:
                self.on_all_complete(self.results)
    
    def get_all_results(self) -> Dict[Tuple[str, float], Any]:
        return self.results

    def export_all_images(self, width: int = 800, height: int = 600) -> Dict[str, List[bytes]]:
        """Eksportuj obrazy ze wszystkich zakladek

        Returns:
            Dict[tab_name, List[png_bytes]] - slownik z lista obrazow per zakladka
        """
        all_images = {}
        for tab_name, tab in self.tabs.items():
            images = tab.export_images(width, height)
            if images:
                all_images[tab_name] = images
        return all_images

    def start_all_nesting(self):
        """Uruchom nesting na wszystkich zakładkach"""
        for tab in self.tabs.values():
            tab.start_nesting()


# ============================================================
# Compatibility exports
# ============================================================

# Dla kompatybilności wstecznej
NestingCanvas = SheetCanvas


# ============================================================
# Test
# ============================================================

if __name__ == "__main__":
    ctk.set_appearance_mode("Dark")
    ctk.set_default_color_theme("blue")
    
    root = ctk.CTk()
    root.title("Multi-Sheet Nesting Test")
    root.geometry("1400x900")
    
    # Dużo detali żeby wymusić wiele arkuszy
    test_data = {
        ("S355", 3.0): [
            {'name': f'Płyta_{i}', 'width': 400 + i*50, 'height': 300 + i*30, 'quantity': 5,
             'contour': [(0, 0), (400+i*50, 0), (400+i*50, 300+i*30), (0, 300+i*30)], 'holes': []}
            for i in range(8)
        ] + [
            {'name': 'ZaDuży', 'width': 5000, 'height': 3000, 'quantity': 2,
             'contour': [], 'holes': []}  # Za duży!
        ],
    }
    
    panel = NestingTabsPanel(
        root,
        parts_by_group=test_data,
        sheet_formats=[(1500, 1000), (2000, 1000), (3000, 1500)],
        on_all_complete=lambda r: print(f"Wszystkie zakończone!")
    )
    panel.pack(fill="both", expand=True)
    
    root.mainloop()
