"""File and name parsers"""
