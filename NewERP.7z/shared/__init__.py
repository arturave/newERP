"""Shared parsers"""
