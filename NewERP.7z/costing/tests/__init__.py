"""Tests for costing module."""
