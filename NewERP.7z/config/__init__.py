#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration module for NewERP
"""

from config.settings import *
